import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";

/* ================= PUBLIC PAGES ================= */
import HomePage from "./pages/Home/HomePage";
import JobsPage from "./pages/Jobs/JobsPage";
import GovJobsPage from "./pages/GovJobs/GovJobsPage";
import DressesPage from "./pages/Dresses/DressesPage";
import JewelleryPage from "./pages/Jewellery/JewelleryPage";
import BooksPage from "./pages/Books/BooksPage";

/* ================= LEGAL PAGES ================= */
import PrivacyPolicy from "./pages/Legal/PrivacyPolicy";
import Terms from "./pages/Legal/Terms";
import Feedback from "./components/Feedback/Feedback";

/* ================= ADMIN ================= */
import ProtectedRoute from "./admin/ProtectedRoute";
import AdminLayout from "./admin/AdminLayout";
import AdminLogin from "./admin/AdminLogin";
import Dashboard from "./admin/Dashboard";
import AdminPrivateJobs from "./admin/AdminPrivateJobs";
import AdminGovtJobs from "./admin/AdminGovtJobs";
import AdminDresses from "./admin/AdminDresses";
import AdminJewellery from "./admin/AdminJewellery";
import AdminBooks from "./admin/AdminBooks";

import "./App.css";

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Header />

        <main className="main-content">
          <Routes>
            {/* ================= PUBLIC ROUTES ================= */}
            <Route path="/" element={<HomePage />} />
            <Route path="/jobs" element={<JobsPage />} />
            <Route path="/government-jobs" element={<GovJobsPage />} />
            <Route path="/dresses" element={<DressesPage />} />
            <Route path="/jewellery" element={<JewelleryPage />} />
            <Route path="/books" element={<BooksPage />} />

            {/* ================= LEGAL ROUTES ================= */}
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/contact" element={<Feedback />} />

            {/* ================= ADMIN ROUTES ================= */}
            <Route path="/admin/login" element={<AdminLogin />} />

            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <AdminLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Dashboard />} />
              <Route path="private-jobs" element={<AdminPrivateJobs />} />
              <Route path="govt-jobs" element={<AdminGovtJobs />} />
              <Route path="dresses" element={<AdminDresses />} />
              <Route path="jewellery" element={<AdminJewellery />} />
              <Route path="books" element={<AdminBooks />} />
            </Route>
          </Routes>
        </main>

        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;