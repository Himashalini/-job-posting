import { useEffect, useState } from "react";
import SearchBar from "../../components/SearchBar/SearchBar";
import JewelleryCard from "../../cards/JewelleryCard";
import Feedback from "../../components/Feedback/Feedback";
import { searchFilter } from "../../utils/searchFilter";
import { getJewellery } from "../../services/jewelleryService";
import PartnerPicks from "../../components/PartnerPicks/PartnerPicks";
import "./JewelleryPage.css";

export default function JewelleryPage() {
  const [items, setItems] = useState([]);
  const [partners, setPartners] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // ✅ single active jewellery purchase form
  const [activeJewellery, setActiveJewellery] = useState(null);

  useEffect(() => {
    getJewellery()
      .then((data) => {
        setItems(data || []);

        const partnerItems = (data || [])
          .filter((j) => j.type === "partner")
          .map((j) => ({
            id: j.id,
            name: j.name,
            description: j.description,
            image:
              Array.isArray(j.images) && j.images.length
                ? j.images[0]
                : j.image_url || "/logo192.png",
            url: j.affiliate_link || j.affiliateLink || j.link || "#",
          }));

        setPartners(partnerItems);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filteredJewellery = searchFilter(items, search);

  if (loading) {
    return <div className="page">Loading jewellery…</div>;
  }

  return (
    <div className="page">
      <h2>Jewellery</h2>

      <SearchBar value={search} onChange={setSearch} />

      <PartnerPicks
        directItems={filteredJewellery}
        partners={partners}
        renderDirectGrid={(items) => (
          <div className="grid">
            {items.length === 0 ? (
              <p>No jewellery found</p>
            ) : (
              items.map((item) => (
                <JewelleryCard
                  key={item.id}
                  jewellery={item}
                  activeJewellery={activeJewellery}
                  setActiveJewellery={setActiveJewellery}
                />
              ))
            )}
          </div>
        )}
      />
    </div>
  );
}