import { Link } from "react-router-dom";
import "./HomePage.css";
import Feedback from "../../components/Feedback/Feedback";

export default function HomePage() {
  return (
    <div className="home">

      {/* ================= HERO ================= */}
      <section className="hero">
        <h1>Jobs, Government Updates & Trending Products</h1>
        <p>
          Find latest private jobs, government notifications, and shop trending
          dresses & jewellery from trusted sources.
        </p>

        <div className="hero-actions">
          <Link to="/jobs" className="btn primary">Explore Jobs</Link>
          <Link to="/dresses" className="btn secondary">Shop Dresses</Link>
        </div>
      </section>

      {/* ================= JOBS ================= */}
      <section className="section">
        <h2>Latest Job Updates</h2>
        <p className="section-sub">
          Verified private & government job notifications
        </p>

        <div className="grid-2">
          <div className="card-info">
            <h3>Private Jobs</h3>
            <p>IT, Non‑IT, Fresher & Experienced opportunities</p>
            <Link to="/jobs" className="link-btn">View Jobs →</Link>
          </div>

          <div className="card-info">
            <h3>Government Jobs</h3>
            <p>Central & State government job notifications</p>
            <Link to="/government-jobs" className="link-btn">View Govt Jobs →</Link>
          </div>
        </div>
      </section>

      {/* ================= SHOPPING ================= */}
      <section className="section alt">
        <h2>Shopping Section</h2>
        <p className="section-sub">Buy or explore partner products safely</p>

        <div className="grid-2">
          <div className="card-info">
            <h3>Direct Buy Collection</h3>
            <p>
              Buy directly via WhatsApp. Verified sellers. Personal support.
            </p>
            <Link to="/dresses" className="link-btn">Buy Dresses →</Link>
          </div>

          <div className="card-info">
            <h3>Partner Picks</h3>
            <p>
              Hand‑picked products from our trusted partners. Partner products & deals. 
            </p>
            <Link to="/dresses" className="link-btn">View Deals →</Link>
          </div>
        </div>
      </section>

      {/* ================= JEWELLERY ================= */}
<section className="section">
  <h2>Jewellery Collection</h2>

  <p className="section-sub">
    Elegant jewellery for daily wear, festivals, and special occasions.
  </p>

  <div className="grid-2">
    <div className="card-info">
      <h3>Direct Buy Jewellery</h3>
      <p>
        Buy jewellery directly with personal WhatsApp support from verified
        sellers. Transparent pricing and assistance available.
      </p>
      <Link to="/jewellery" className="link-btn">
        Shop Jewellery →
      </Link>
    </div>

    <div className="card-info">
      <h3>Partner Picks</h3>
      <p>
        Hand‑picked jewellery collections from our trusted partner stores.
        Explore trending styles and exclusive deals.
      </p>
      <Link to="/jewellery" className="link-btn">
        View Partner Picks →
      </Link>
    </div>
  </div>
</section>

      {/* ================= TRUST ================= */}
      <section className="section alt trust">
        <h2>Trusted & Transparent</h2>
        <p>
          We provide genuine job information and clearly marked affiliate
          products. User trust is our priority.
        </p>
        <Link to="/feedback" className="link-btn">Send Feedback →</Link>
      </section>
      <Feedback />

    </div>
  );
}