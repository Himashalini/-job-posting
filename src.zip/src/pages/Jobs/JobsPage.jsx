import { useEffect, useState } from "react";
import SearchBar from "../../components/SearchBar/SearchBar";
import JobCard from "../../cards/JobCard";
import Feedback from "../../components/Feedback/Feedback";
import { searchFilter } from "../../utils/searchFilter";
import { getJobs } from "../../services/jobService";
import "./JobsPage.css";

export default function JobsPage() {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getJobs()
      .then(setJobs)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filteredJobs = searchFilter(jobs, search);

  if (loading) {
    return <div className="jobs-page">Loading jobs…</div>;
  }

  return (
    <div className="jobs-page">
      <h2>Job Openings</h2>

      <SearchBar value={search} onChange={setSearch} />

      <div className="jobs-grid">
        {filteredJobs.length === 0 ? (
          <p className="jobs-empty">No jobs found</p>
        ) : (
          filteredJobs.map(job => (
            <JobCard key={job.id} job={job} />
          ))
        )}
      </div>

    </div>
  );
}