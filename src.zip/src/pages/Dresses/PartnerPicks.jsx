import "./DressesPage.css";

export default function PartnerPicks() {
  const partnerDresses = [
    {
      id: 2,
      name: "Floral Summer Dress",
      description: "Lightweight and perfect for daily wear.",
      image: "https://via.placeholder.com/300",
      link: "https://example.com/dress1",
    },
    {
      id: 3,
      name: "Party Wear Long Gown",
      description: "Elegant style for special occasions.",
      image: "https://via.placeholder.com/300",
      link: "https://example.com/dress2",
    },
  ];

  return (
    <div className="page">
      <h2>Partner Picks</h2>

      <p className="section-sub">
        Hand‑picked dresses from our trusted partner stores.
      </p>

      <div className="grid">
        {partnerDresses.map(item => (
          <div className="card" key={item.id}>
            <img src={item.image} alt={item.name} />

            <h3>{item.name}</h3>
            <p className="desc">{item.description}</p>

            <a
              href={item.link}
              target="_blank"
              rel="noreferrer"
              className="partner-btn"
            >
              View at Store
            </a>

            {/* ✅ required but subtle disclosure */}
            <p className="small center">Partner Pick</p>
          </div>
        ))}
      </div>

      {/* ✅ Google Ads compliant disclosure */}
      <p className="small center">
        Some products shown here are Partner Picks. We may earn a commission
        at no extra cost to you.
      </p>
    </div>
  );
}