import { useEffect, useState } from "react";
import SearchBar from "../../components/SearchBar/SearchBar";
import DressCard from "../../cards/DressCard";
import Feedback from "../../components/Feedback/Feedback";
import { searchFilter } from "../../utils/searchFilter";
import { getDresses } from "../../services/dressService";
import PartnerPicks from "../../components/PartnerPicks/PartnerPicks";
import "./DressesPage.css";

export default function DressesPage() {
  const [dresses, setDresses] = useState([]);
  const [partners, setPartners] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // ✅ single active purchase form
  const [activeDress, setActiveDress] = useState(null);

  useEffect(() => {
    getDresses()
      .then((data) => {
        setDresses(data || []);

        const partnerItems = (data || [])
          .filter((d) => d.type === "partner")
          .map((d) => ({
            id: d.id,
            name: d.name,
            description: d.description,
            image:
              Array.isArray(d.images) && d.images.length
                ? d.images[0]
                : d.image_url || "/logo192.png",
            url: d.affiliate_link || d.affiliateLink || d.link || "#",
          }));

        setPartners(partnerItems);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filteredDresses = searchFilter(dresses, search);

  if (loading) {
    return <div className="page">Loading dresses…</div>;
  }

  return (
    <div className="page">
      <h2>Dresses</h2>

      <SearchBar value={search} onChange={setSearch} />

      <PartnerPicks
        directItems={filteredDresses}
        partners={partners}
        renderDirectGrid={(items) => (
          <div className="grid">
            {items.length === 0 ? (
              <p>No dresses found</p>
            ) : (
              items.map((dress) => (
                <DressCard
                  key={dress.id}
                  dress={dress}
                  activeDress={activeDress}
                  setActiveDress={setActiveDress}
                />
              ))
            )}
          </div>
        )}
      />
    </div>
  );
}