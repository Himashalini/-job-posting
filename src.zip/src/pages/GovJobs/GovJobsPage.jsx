import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import SearchBar from "../../components/SearchBar/SearchBar";
import Feedback from "../../components/Feedback/Feedback";
import "./GovJobsPage.css";

export default function GovJobsPage() {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const BASE = process.env.REACT_APP_API_BASE_URL || "";
    fetch(`${BASE}/govt-jobs?search=${encodeURIComponent(search)}`)
      .then(res => {
        if (!res.ok) throw new Error(`Server responded with ${res.status}`);
        return res.json();
      })
      .then(data => setJobs(Array.isArray(data) ? data : []))
      .catch(err => {
        console.error("Failed to load government jobs:", err);
        toast.error("Unable to load government jobs.");
        setJobs([]);
      });
  }, [search]);

  return (
    <div className="gov-jobs-page">
      <h2>Government Jobs</h2>

      <SearchBar value={search} onChange={setSearch} />

      <div className="gov-jobs-grid">
        {jobs.map(job => (
          <div key={job.id} className="gov-job-card">
            <h3>{job.title}</h3>

            <p><strong>Department:</strong> {job.department}</p>
            <p><strong>Qualification:</strong> {job.qualification}</p>
            <p><strong>Age:</strong> {job.age_limit}</p>
            <p><strong>Salary:</strong> {job.salary}</p>
            <p><strong>Apply By:</strong> {job.application_end}</p>

            <a href={job.notification_pdf} target="_blank" rel="noreferrer">
              <button className="gov-job-btn">View Notification</button>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}