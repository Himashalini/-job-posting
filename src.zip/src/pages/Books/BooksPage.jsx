import { useEffect, useState } from "react";
import SearchBar from "../../components/SearchBar/SearchBar";
import BookCard from "../../cards/BookCard";
import Feedback from "../../components/Feedback/Feedback";
import { searchFilter } from "../../utils/searchFilter";
import PartnerPicks from "../../components/PartnerPicks/PartnerPicks";
import "./BooksPage.css";

export default function BooksPage() {
  const [books, setBooks] = useState([]);
  const [partners, setPartners] = useState([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // ✅ single active book purchase form
  const [activeBook, setActiveBook] = useState(null);

  useEffect(() => {
    const base = process.env.REACT_APP_API_BASE_URL || "";

    fetch(`${base}/books`)
      .then(res => res.json())
      .then(data => {
        setBooks(data || []);

        const partnerItems = (data || [])
          .filter(b => b.type === "partner")
          .map(b => ({
            id: b.id,
            name: b.title || b.name,
            description: b.description,
            image:
              Array.isArray(b.images) && b.images.length
                ? b.images[0]
                : "/logo192.png",
            url: b.affiliate_link || b.affiliateLink || b.link || "#",
          }));

        setPartners(partnerItems);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const filteredBooks = searchFilter(books, search);

  if (loading) {
    return <div className="page">Loading books…</div>;
  }

  return (
    <div className="page">
      <h2>Books</h2>

      <SearchBar value={search} onChange={setSearch} />

      <PartnerPicks
        directItems={filteredBooks}
        partners={partners}
        renderDirectGrid={items => (
          <div className="grid">
            {items.length === 0 ? (
              <p>No books found</p>
            ) : (
              items.map(book => (
                <BookCard
                  key={book.id}
                  book={book}
                  activeBook={activeBook}
                  setActiveBook={setActiveBook}
                />
              ))
            )}
          </div>
        )}
      />

      <Feedback />
    </div>
  );
}