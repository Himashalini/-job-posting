export default function PrivacyPolicy() {
  return (
    <div className="page">
      <h2>Privacy Policy</h2>

      <p>
        Your privacy is important to us. This Privacy Policy explains what
        information we collect, how we use it, and the choices you have about
        that information when you use Job & Deals.
      </p>

      <h3>Information We Collect</h3>
      <p>
        We collect information you provide directly (for example, when you
        contact us via forms or WhatsApp). This may include your name, phone
        number, email address, and any message or order details you submit.
      </p>

      <h3>How We Use Your Information</h3>
      <p>
        We use the information to respond to inquiries, process orders via
        WhatsApp or partner sites, and to improve our services. We do not sell
        your personal information to third parties.
      </p>

      <h3>Cookies & Advertising</h3>
      <p>
        We use cookies and similar technologies to provide and improve our
        services. We may display third‑party advertising such as Google AdSense
        on our site. These third parties may set cookies and use web beacons
        to collect information about your use of the site in order to provide
        personalized ads. You can opt out of personalized advertising through
        your Google Ad Settings: https://adssettings.google.com
      </p>

      <h3>Third‑Party Links and Affiliate Links</h3>
      <p>
        Some product listings are Partner Picks and contain affiliate links.
        If you click a Partner Pick and complete a purchase, we may earn a
        commission at no extra cost to you. Affiliate links will open in a new
        tab and will be labeled appropriately in the UI. We are not
        responsible for the privacy practices of partner websites.
      </p>

      <h3>Analytics</h3>
      <p>
        We may use third‑party analytics services to understand site usage
        (for example Google Analytics). These services may collect information
        about your use of the site. See the providers' privacy policies for
        details on how they handle data.
      </p>

      <h3>Security</h3>
      <p>
        We take reasonable measures to protect your information. However, no
        system is completely secure; we cannot guarantee the absolute security
        of data transmitted to or from our site.
      </p>

      <h3>Updates</h3>
      <p>
        We may update this Privacy Policy. Changes will be posted on this
        page; continued use of the site after changes constitutes acceptance
        of the updated terms.
      </p>

      <p>
        Questions? Contact us via the Contact page or email: himashalini676@gmail.com
      </p>
    </div>
  );
}