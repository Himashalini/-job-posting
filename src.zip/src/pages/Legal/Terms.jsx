export default function Terms() {
  return (
    <div className="page">
      <h2>Terms & Conditions</h2>

      <p>
        By using this website, you agree to comply with and be bound by the
        following terms and conditions.
      </p>

      <h3>Website Content</h3>
      <p>
        The information provided on this website is for general informational
        purposes only. Job listings, product details, and prices may change
        without notice.
      </p>

      <h3>Jobs Information</h3>
      <p>
        Job details are shared for informational purposes. We do not guarantee
        job placement or recruitment and are not responsible for employer
        decisions.
      </p>

      <h3>Purchases & Orders</h3>
      <p>
        Some products are offered through direct communication platforms such
        as WhatsApp, while others may redirect to third‑party partner websites.
        We do not control payments or deliveries handled by external sellers.
      </p>

      <h3>Affiliate Disclaimer</h3>
      <p>
        Some links on this website may be partner or affiliate links. We may
        earn a commission if you purchase through those links, at no extra
        cost to you.
      </p>

      <h3>User Responsibility</h3>
      <p>
        Users are responsible for verifying information before making job
        applications or purchase decisions.
      </p>

      <h3>External Links</h3>
      <p>
        This website may contain links to third‑party websites. We are not
        responsible for the content or practices of those websites.
      </p>

      <h3>Changes to Terms</h3>
      <p>
        We reserve the right to update these terms at any time. Continued use
        of the website means acceptance of updated terms.
      </p>
    </div>
  );
}
