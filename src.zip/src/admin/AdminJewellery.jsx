import { useEffect, useState } from "react";
import AdminForm from "./AdminForm";
import EditForm from "./EditForm";
import { toast } from "react-toastify";

/* =========================
   CONFIRM MODAL
   ========================= */
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <h4>Confirm Action</h4>
        <p>{message}</p>
        <div className="confirm-actions">
          <button className="btn btn-delete" onClick={onConfirm}>
            Yes, Delete
          </button>
          <button className="btn btn-edit" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminJewellery() {
  const [items, setItems] = useState([]);
  const [editingItem, setEditingItem] = useState(null);
  const [currentImages, setCurrentImages] = useState([]);
  const [deleteId, setDeleteId] = useState(null);

  const token = localStorage.getItem("token");
  const BASE = process.env.REACT_APP_API_BASE_URL || "";

  /* =========================
     FETCH JEWELLERY
     ========================= */
  const fetchJewellery = async () => {
    try {
      const res = await fetch(`${BASE}/jewellery`);
      const data = await res.json();
      setItems(data);
    } catch {
      toast.error("❌ Failed to load jewellery");
    }
  };

  useEffect(() => {
    fetchJewellery();
  }, []);

  /* =========================
     BUILD PAYLOAD
     ========================= */
  const buildPayload = (data, replaceImages = false) => ({
    name: data.name?.trim(),
    price: Number(data.price),
    description: data.description?.trim(),
    type: data.type || "direct",
    affiliate_link: data.affiliate_link?.trim() || null,
    replaceImages,
    images: data.images
      ? data.images
          .split(",")
          .map(i => i.replace(/&amp;/g, "&").trim())
          .filter(Boolean)
      : [],
  });

  /* =========================
     CREATE JEWELLERY
     ========================= */
  const createJewellery = async data => {
    try {
      await fetch(`${BASE}/jewellery`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(buildPayload(data)),
      });

      toast.success("✅ Jewellery added");
      fetchJewellery();
    } catch {
      toast.error("❌ Failed to add jewellery");
    }
  };

  /* =========================
     UPDATE JEWELLERY
     ========================= */
  const updateJewellery = async data => {
    try {
      const payload = buildPayload(data, true);

      // keep remaining + new images
      payload.images = [
        ...currentImages,
        ...payload.images,
      ];

      await fetch(`${BASE}/jewellery/${editingItem.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      toast.success("✅ Jewellery updated");
      setEditingItem(null);
      setCurrentImages([]);
      fetchJewellery();
    } catch {
      toast.error("❌ Update failed");
    }
  };

  /* =========================
     DELETE SINGLE IMAGE
     ========================= */
  const deleteImage = async imageUrl => {
    try {
      await fetch(`${BASE}/jewellery/${editingItem.id}/image`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ image_url: imageUrl }),
      });

      setCurrentImages(prev => prev.filter(img => img !== imageUrl));
      toast.success("✅ Image deleted");
    } catch {
      toast.error("❌ Image delete failed");
    }
  };

  /* =========================
     DELETE JEWELLERY
     ========================= */
  const confirmDelete = async () => {
    try {
      await fetch(`${BASE}/jewellery/${deleteId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      setItems(prev => prev.filter(i => i.id !== deleteId));
      toast.success("✅ Jewellery deleted");
    } catch {
      toast.error("❌ Failed to delete jewellery");
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <div>
      <h2>Jewellery</h2>

      {/* ✅ EDIT MODE */}
      {editingItem && (
        <>
          <h4>Existing Images</h4>

          {currentImages.length === 0 && <p>No images</p>}

          <div style={{ display: "flex", gap: 15, flexWrap: "wrap" }}>
            {currentImages.map((img, idx) => (
              <div
                key={idx}
                style={{
                  border: "1px solid #ccc",
                  padding: 8,
                  textAlign: "center",
                  width: 160,
                }}
              >
                <img
                  src={img}
                  alt="Jewellery"
                  style={{
                    width: "150px",
                    height: "200px",
                    objectFit: "cover",
                    marginBottom: 8,
                  }}
                />

                <button
                  className="btn btn-delete"
                  onClick={() => deleteImage(img)}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>

          <EditForm
            initialData={{
              ...editingItem,
              images: "", // ✅ add new images only
            }}
            fields={[
              "name",
              "price",
              "description",
              "images",
              "type",
              "affiliate_link",
            ]}
            onSave={updateJewellery}
            onCancel={() => {
              setEditingItem(null);
              setCurrentImages([]);
            }}
          />
        </>
      )}

      {/* ✅ TABLE */}
      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Jewellery</th>
            <th>Price</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map(j => (
            <tr key={j.id}>
              <td>{j.id}</td>
              <td>{j.name}</td>
              <td>₹{j.price}</td>
              <td>{j.type}</td>
              <td>
                <button
                  className="btn btn-edit"
                  onClick={() => {
                    setEditingItem(j);
                    setCurrentImages([...j.images]);
                  }}
                >
                  Edit
                </button>
                <button
                  className="btn btn-delete"
                  onClick={() => setDeleteId(j.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ✅ CREATE FORM */}
      <AdminForm
        fields={[
          "name",
          "price",
          "description",
          "images",
          "type",
          "affiliate_link",
        ]}
        onSubmit={createJewellery}
      />

      {deleteId && (
        <ConfirmModal
          message="Are you sure you want to delete this jewellery?"
          onConfirm={confirmDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}
