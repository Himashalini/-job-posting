import { useEffect, useState } from "react";
import AdminForm from "./AdminForm";
import EditForm from "./EditForm";
import { toast } from "react-toastify";

/* =========================
   CONFIRM MODAL
   ========================= */
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <h4>Confirm Action</h4>
        <p>{message}</p>
        <div className="confirm-actions">
          <button className="btn btn-delete" onClick={onConfirm}>
            Yes, Delete
          </button>
          <button className="btn btn-edit" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminDresses() {
  const [dresses, setDresses] = useState([]);
  const [editingDress, setEditingDress] = useState(null);
  const [currentImages, setCurrentImages] = useState([]);
  const [deleteId, setDeleteId] = useState(null);

  const token = localStorage.getItem("token");
  const BASE = process.env.REACT_APP_API_BASE_URL || "";

  /* =========================
     FETCH DRESSES
     ========================= */
  const fetchDresses = async () => {
    try {
      const res = await fetch(`${BASE}/dresses`);
      const data = await res.json();
      setDresses(data);
    } catch {
      toast.error("❌ Failed to load dresses");
    }
  };

  useEffect(() => {
    fetchDresses();
  }, []);

  /* =========================
     BUILD PAYLOAD
     ========================= */
  const buildPayload = (data, replaceImages = false) => ({
    name: data.name?.trim(),
    price: Number(data.price),
    description: data.description?.trim(),
    type: data.type || "direct",
    affiliate_link: data.affiliate_link?.trim() || null,
    replaceImages,
    images: data.images
      ? data.images
          .split(",")
          .map(i => i.replace(/&amp;/g, "&").trim())
          .filter(Boolean)
      : [],
  });

  /* =========================
     CREATE DRESS
     ========================= */
  const createDress = async data => {
    try {
      await fetch(`${BASE}/dresses`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(buildPayload(data)),
      });

      toast.success("✅ Dress added");
      fetchDresses();
    } catch {
      toast.error("❌ Failed to add dress");
    }
  };

  /* =========================
     UPDATE DRESS
     ========================= */
  const updateDress = async data => {
    try {
      const payload = buildPayload(data, true);

      payload.images = [
        ...currentImages, // remaining images
        ...payload.images, // newly added
      ];

      await fetch(`${BASE}/dresses/${editingDress.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      toast.success("✅ Dress updated");
      setEditingDress(null);
      setCurrentImages([]);
      fetchDresses();
    } catch {
      toast.error("❌ Update failed");
    }
  };

  /* =========================
     DELETE SINGLE IMAGE
     ========================= */
  const deleteImage = async imageUrl => {
    try {
      await fetch(`${BASE}/dresses/${editingDress.id}/image`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ image_url: imageUrl }),
      });

      setCurrentImages(prev => prev.filter(img => img !== imageUrl));
      toast.success("✅ Image deleted");
    } catch {
      toast.error("❌ Image delete failed");
    }
  };

  /* =========================
     DELETE DRESS
     ========================= */
  const confirmDelete = async () => {
    try {
      await fetch(`${BASE}/dresses/${deleteId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      setDresses(prev => prev.filter(d => d.id !== deleteId));
      toast.success("✅ Dress deleted");
    } catch {
      toast.error("❌ Failed to delete dress");
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <div>
      <h2>Dresses</h2>

      {/* ✅ EDIT MODE */}
      {editingDress && (
        <>
          <h4>Existing Images</h4>

          {currentImages.length === 0 && <p>No images</p>}

          <div style={{ display: "flex", gap: 15, flexWrap: "wrap" }}>
            {currentImages.map((img, idx) => (
              <div
                key={idx}
                style={{
                  border: "1px solid #ccc",
                  padding: 8,
                  textAlign: "center",
                  width: 160,
                }}
              >
                <img
                  src={img}
                  alt="Dress"
                  style={{
                    width: "150px",
                    height: "200px",
                    objectFit: "cover",
                    marginBottom: 8,
                  }}
                />

                <button
                  className="btn btn-delete"
                  onClick={() => deleteImage(img)}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>

          <EditForm
            initialData={{
              ...editingDress,
              images: "", // ✅ add new images only
            }}
            fields={[
              "name",
              "price",
              "description",
              "images",
              "type",
              "affiliate_link",
            ]}
            onSave={updateDress}
            onCancel={() => {
              setEditingDress(null);
              setCurrentImages([]);
            }}
          />
        </>
      )}

      {/* ✅ TABLE */}
      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Dress</th>
            <th>Price</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {dresses.map(d => (
            <tr key={d.id}>
              <td>{d.id}</td>
              <td>{d.name}</td>
              <td>₹{d.price}</td>
              <td>{d.type}</td>
              <td>
                <button
                  className="btn btn-edit"
                  onClick={() => {
                    setEditingDress(d);
                    setCurrentImages([...d.images]);
                  }}
                >
                  Edit
                </button>
                <button
                  className="btn btn-delete"
                  onClick={() => setDeleteId(d.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ✅ CREATE FORM */}
      <AdminForm
        fields={[
          "name",
          "price",
          "description",
          "images",
          "type",
          "affiliate_link",
        ]}
        onSubmit={createDress}
      />

      {deleteId && (
        <ConfirmModal
          message="Are you sure you want to delete this dress?"
          onConfirm={confirmDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}
