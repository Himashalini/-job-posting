import { Navigate } from "react-router-dom";

export default function ProtectedRoute({ children }) {
  const token = localStorage.getItem("token");

  // ✅ If token exists → allow access
  if (token) {
    return children;
  }

  // ❌ If not logged in → redirect to admin login
  return <Navigate to="/admin/login" replace />;
}