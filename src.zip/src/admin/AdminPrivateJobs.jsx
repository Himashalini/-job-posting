import { useEffect, useState } from "react";
import AdminForm from "./AdminForm";
import EditForm from "./EditForm";
import { toast } from "react-toastify";

/* =========================
   CONFIRM MODAL
   ========================= */
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <h4>Confirm Action</h4>
        <p>{message}</p>

        <div className="confirm-actions">
          <button className="btn btn-delete" onClick={onConfirm}>
            Yes, Delete
          </button>
          <button className="btn btn-edit" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminPrivateJobs() {
  const [jobs, setJobs] = useState([]);
  const [editingJob, setEditingJob] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [loading, setLoading] = useState(false);

  /* ✅ PAGINATION STATE */
  const [page, setPage] = useState(1);
  const limit = 5;

  const token = localStorage.getItem("token");

  /* =========================
     FETCH ALL JOBS (PAGINATED)
     ========================= */
  useEffect(() => {
    const BASE = process.env.REACT_APP_API_BASE_URL || "";
    fetch(`${BASE}/jobs?page=${page}&limit=${limit}`)
      .then((res) => res.json())
      .then((data) => {
        // Normalize response to always be an array
        if (Array.isArray(data)) return setJobs(data);
        if (data && Array.isArray(data.data)) return setJobs(data.data);
        if (data && Array.isArray(data.jobs)) return setJobs(data.jobs);
        if (data && Array.isArray(data.results)) return setJobs(data.results);

        // Fallback: if it's an object with values, try to coerce to array
        if (data && typeof data === "object") return setJobs(Object.values(data));

        // Default empty
        setJobs([]);
      })
      .catch(() => toast.error("❌ Failed to load jobs"));
  }, [page]);

  /* =========================
     CREATE JOB
     ========================= */
  const createJob = async (data) => {
    setLoading(true);
    try {
      const BASE = process.env.REACT_APP_API_BASE_URL || "";
      await fetch(`${BASE}/jobs`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });

      toast.success("✅ Job added successfully");
      setTimeout(() => window.location.reload(), 800);
    } catch {
      toast.error("❌ Failed to add job");
    } finally {
      setLoading(false);
    }
  };

  /* =========================
     UPDATE JOB
     ========================= */
  const updateJob = async (data) => {
    setLoading(true);
    try {
      const BASE = process.env.REACT_APP_API_BASE_URL || "";
      await fetch(`${BASE}/jobs/${editingJob.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(data),
      });

      toast.success("✅ Job updated successfully");
      setEditingJob(null);
      setTimeout(() => window.location.reload(), 800);
    } catch {
      toast.error("❌ Failed to update job");
    } finally {
      setLoading(false);
    }
  };

  /* =========================
     DELETE JOB (CONFIRM)
     ========================= */
  const confirmDelete = async () => {
    setLoading(true);
    try {
      const BASE = process.env.REACT_APP_API_BASE_URL || "";
      await fetch(`${BASE}/jobs/${deleteId}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      setJobs(prev => prev.filter(job => job.id !== deleteId));
      toast.success("✅ Job deleted successfully");
    } catch {
      toast.error("❌ Failed to delete job");
    } finally {
      setDeleteId(null);
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Private Jobs</h2>

      {/* =========================
         EDIT FORM
         ========================= */}
      {editingJob && (
        <EditForm
          initialData={editingJob}
          fields={[
            "title",
            "company",
            "description",
            "image_url",
            "apply_link",
          ]}
          onSave={updateJob}
          onCancel={() => setEditingJob(null)}
        />
      )}

      {/* =========================
         LIST TABLE
         ========================= */}
      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Job Title</th>
            <th>Company</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {jobs.map(job => (
            <tr key={job.id}>
              <td>{job.id}</td>
              <td>{job.title}</td>
              <td>{job.company}</td>
              <td>
                <button
                  className="btn btn-edit"
                  disabled={loading}
                  onClick={() => setEditingJob(job)}
                >
                  {loading ? "Saving..." : "Edit"}
                </button>

                <button
                  className="btn btn-delete"
                  disabled={loading}
                  onClick={() => setDeleteId(job.id)}
                >
                  {loading ? "Deleting..." : "Delete"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ✅ PAGINATION CONTROLS */}
      <div style={{ display: "flex", gap: "12px", marginTop: "15px" }}>
        <button
          className="btn"
          disabled={page === 1}
          onClick={() => setPage(p => p - 1)}
        >
          Previous
        </button>

        <span>Page {page}</span>

        <button
          className="btn"
          onClick={() => setPage(p => p + 1)}
        >
          Next
        </button>
      </div>

      <h3>Add New Job</h3>

      {/* =========================
         CREATE FORM
         ========================= */}
      <AdminForm
        fields={[
          "id",
          "title",
          "company",
          "description",
          "image_url",
          "apply_link",
        ]}
        onSubmit={createJob}
      />

      {/* =========================
         CONFIRM DELETE MODAL
         ========================= */}
      {deleteId && (
        <ConfirmModal
          message="Are you sure you want to delete this job?"
          onConfirm={confirmDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}