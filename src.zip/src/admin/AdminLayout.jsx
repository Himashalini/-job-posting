import { Link, Outlet, useNavigate } from "react-router-dom";
import "./admin.css";

export default function AdminLayout() {
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/admin/login");
  };

  return (
    <div className="admin">
      {/* ✅ ISOLATED SIDEBAR */}
      <nav className="admin-navbar">
        <h3 className="admin-navbar-title">Admin Panel</h3>

        <Link to="/admin">Dashboard</Link>
        <Link to="/admin/private-jobs">Private Jobs</Link>
        <Link to="/admin/govt-jobs">Government Jobs</Link>
        <Link to="/admin/dresses">Dresses</Link>
        <Link to="/admin/jewellery">Jewellery</Link>
        <Link to="/admin/books">Books</Link>

        <button onClick={logout}>Logout</button>
      </nav>

      {/* ✅ PAGE CONTENT */}
      <div className="admin-content">
        <Outlet />
      </div>
    </div>
  );
}
