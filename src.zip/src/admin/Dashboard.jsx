import { useNavigate } from "react-router-dom";

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <p style={{ marginBottom: "20px", color: "#4b5563" }}>
        Manage all application data from here.
      </p>

      <div className="dashboard-cards">
        <div className="dash-card">
          <h3>Private Jobs</h3>
          <p>Add, edit, and delete private job postings.</p>
          <button className="btn" onClick={() => navigate("/admin/private-jobs")}>Open</button>
        </div>

        <div className="dash-card">
          <h3>Government Jobs</h3>
          <p>Manage government job notifications and updates.</p>
          <button className="btn" onClick={() => navigate("/admin/govt-jobs")}>Open</button>
        </div>

        <div className="dash-card">
          <h3>Dresses</h3>
          <p>Control dress listings, prices, and images.</p>
          <button className="btn" onClick={() => navigate("/admin/dresses")}>Open</button>
        </div>

        <div className="dash-card">
          <h3>Jewellery</h3>
          <p>Maintain jewellery items and pricing details.</p>
          <button className="btn" onClick={() => navigate("/admin/jewellery")}>Open</button>
        </div>

         <div className="dash-card">
          <h3>Books</h3>
          <p>Manage book listings, prices, and descriptions.</p>
          <button className="btn" onClick={() => navigate("/admin/books")}>Open</button>
        </div>
      </div>
    </div>
  );
}