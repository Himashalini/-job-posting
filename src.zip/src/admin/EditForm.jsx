import { useState } from "react";

export default function EditForm({ initialData, fields, onSave, onCancel }) {
  const [formData, setFormData] = useState({ ...initialData, type: initialData?.type || "direct" });

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const ASSET_BASE = (process.env.REACT_APP_API_BASE_URL || "").replace(/\/api\/?$/i, "").replace(/\/$/, "");

  const getImagesArray = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    return String(val)
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
  };

  const images = getImagesArray(formData.images);

  return (
    <form onSubmit={handleSubmit}>
      <h3>Edit Details</h3>

      {fields.map((field) => {
        if (field === "type") {
          return (
            <select
              key={field}
              value={formData.type}
              onChange={(e) => handleChange("type", e.target.value)}
            >
              <option value="direct">Direct</option>
              <option value="partner">Partner</option>
            </select>
          );
        }

        if (field === "affiliate_link") {
          return (
            formData.type === "partner" && (
              <input
                key={field}
                type="text"
                placeholder="affiliate link"
                value={formData.affiliate_link ?? ""}
                onChange={(e) => handleChange("affiliate_link", e.target.value)}
                className="affiliate-input"
                required={formData.type === "partner"}
              />
            )
          );
        }

        return (
          <input
            key={field}
            type="text"
            placeholder={field.replace(/_/g, " ")}
            value={formData[field] ?? ""}
            onChange={(e) => handleChange(field, e.target.value)}
            className={field === "affiliate_link" ? "affiliate-input" : ""}
            required={field !== "images"}
          />
        );
      })}

      {/* Thumbnails preview */}
      {images.length > 0 && (
        <div className="thumb-row" style={{ display: "flex", gap: 8, marginTop: 8, marginBottom: 8 }}>
          {images.map((src, idx) => {
            const url = src.startsWith("http") ? src : `${ASSET_BASE}/${src.replace(/^\//, "")}`;
            return (
              <img
                key={idx}
                src={url}
                alt=""
                style={{ width: 80, height: 80, objectFit: "cover", borderRadius: 4 }}
                onError={(e) => (e.currentTarget.src = "/logo192.png")}
              />
            );
          })}
        </div>
      )}

      <div style={{ display: "flex", gap: "10px" }}>
        <button type="submit">Update</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}