import { useEffect, useState } from "react";
import AdminForm from "./AdminForm";
import EditForm from "./EditForm";
import { toast } from "react-toastify";

/* =========================
   CONFIRM MODAL
   ========================= */
function ConfirmModal({ message, onConfirm, onCancel }) {
  return (
    <div className="confirm-overlay">
      <div className="confirm-box">
        <h4>Confirm Action</h4>
        <p>{message}</p>
        <div className="confirm-actions">
          <button className="btn btn-delete" onClick={onConfirm}>
            Yes, Delete
          </button>
          <button className="btn btn-edit" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AdminBooks() {
  const [books, setBooks] = useState([]);
  const [editingBook, setEditingBook] = useState(null);
  const [currentImages, setCurrentImages] = useState([]);
  const [deleteId, setDeleteId] = useState(null);

  const token = localStorage.getItem("token");
  const BASE = process.env.REACT_APP_API_BASE_URL || "";

  /* =========================
     FETCH BOOKS
     ========================= */
  const fetchBooks = async () => {
    try {
      const res = await fetch(`${BASE}/books`);
      const data = await res.json();
      setBooks(data);
    } catch {
      toast.error("❌ Failed to load books");
    }
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  /* =========================
     BUILD PAYLOAD
     ========================= */
  const buildPayload = (data, replaceImages = false) => ({
    title: data.title?.trim(),
    price: Number(data.price),
    description: data.description?.trim(),
    type: data.type || "direct",
    affiliate_link: data.affiliate_link?.trim() || null,
    replaceImages,
    images: data.images
      ? data.images
          .split(",")
          .map(i => i.replace(/&amp;/g, "&").trim())
          .filter(Boolean)
      : [],
  });

  /* =========================
     CREATE BOOK
     ========================= */
  const createBook = async data => {
    try {
      await fetch(`${BASE}/books`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(buildPayload(data)),
      });

      toast.success("✅ Book added");
      fetchBooks();
    } catch {
      toast.error("❌ Failed to add book");
    }
  };

  /* =========================
     UPDATE BOOK
     ========================= */
  const updateBook = async data => {
    try {
      const payload = buildPayload(data, true);

      payload.images = [
        ...currentImages, // remaining images
        ...payload.images, // newly added
      ];

      await fetch(`${BASE}/books/${editingBook.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      toast.success("✅ Book updated");
      setEditingBook(null);
      setCurrentImages([]);
      fetchBooks();
    } catch {
      toast.error("❌ Update failed");
    }
  };

  /* =========================
     DELETE SINGLE IMAGE
     ========================= */
  const deleteImage = async imageUrl => {
    try {
      await fetch(`${BASE}/books/${editingBook.id}/image`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ image_url: imageUrl }),
      });

      setCurrentImages(prev => prev.filter(img => img !== imageUrl));
      toast.success("✅ Image deleted");
    } catch {
      toast.error("❌ Image delete failed");
    }
  };

  /* =========================
     DELETE BOOK
     ========================= */
  const confirmDelete = async () => {
    try {
      await fetch(`${BASE}/books/${deleteId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      setBooks(prev => prev.filter(b => b.id !== deleteId));
      toast.success("✅ Book deleted");
    } catch {
      toast.error("❌ Failed to delete book");
    } finally {
      setDeleteId(null);
    }
  };

  return (
    <div>
      <h2>Books</h2>

      {/* ✅ EDIT MODE */}
      {editingBook && (
        <>
          <h4>Existing Images</h4>

          {currentImages.length === 0 && <p>No images</p>}

          <div style={{ display: "flex", gap: 15, flexWrap: "wrap" }}>
            {currentImages.map((img, idx) => (
              <div
                key={idx}
                style={{
                  border: "1px solid #ccc",
                  padding: 8,
                  textAlign: "center",
                  width: 160,
                }}
              >
                <img
                  src={img}
                  alt="Book"
                  style={{
                    width: "150px",
                    height: "200px",
                    objectFit: "cover",
                    marginBottom: 8,
                  }}
                />

                <button
                  className="btn btn-delete"
                  onClick={() => deleteImage(img)}
                >
                  Delete
                </button>
              </div>
            ))}
          </div>

          <EditForm
            initialData={{
              ...editingBook,
              images: "", // ✅ add new images only
            }}
            fields={[
              "title",
              "price",
              "description",
              "images",
              "type",
              "affiliate_link",
            ]}
            onSave={updateBook}
            onCancel={() => {
              setEditingBook(null);
              setCurrentImages([]);
            }}
          />
        </>
      )}

      {/* ✅ TABLE */}
      <table className="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Book</th>
            <th>Price</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map(b => (
            <tr key={b.id}>
              <td>{b.id}</td>
              <td>{b.title}</td>
              <td>₹{b.price}</td>
              <td>{b.type}</td>
              <td>
                <button
                  className="btn btn-edit"
                  onClick={() => {
                    setEditingBook(b);
                    setCurrentImages([...b.images]);
                  }}
                >
                  Edit
                </button>
                <button
                  className="btn btn-delete"
                  onClick={() => setDeleteId(b.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* ✅ CREATE FORM */}
      <AdminForm
        fields={[
          "title",
          "price",
          "description",
          "images",
          "type",
          "affiliate_link",
        ]}
        onSubmit={createBook}
      />

      {deleteId && (
        <ConfirmModal
          message="Are you sure you want to delete this book?"
          onConfirm={confirmDelete}
          onCancel={() => setDeleteId(null)}
        />
      )}
    </div>
  );
}