import { NavLink } from "react-router-dom";
import { useState } from "react";
import "./Header.css";
import logo from "../../assets/logo.png";

export default function Header() {
  const [open, setOpen] = useState(false);

  const navClass = ({ isActive }) =>
    isActive ? "nav-link active" : "nav-link";

  return (
    <header className={`header ${open ? "header-open" : ""}`}>
      {/* LOGO */}
      <div className="logo">
        <NavLink to="/" onClick={() => setOpen(false)}>
          <img src={logo} alt="Job & Deals Logo" />
        </NavLink>
      </div>

      {/* MOBILE MENU BUTTON */}
      <div
        className={`menu-toggle ${open ? "open" : ""}`}
        onClick={() => setOpen(!open)}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>

      {/* NAV LINKS */}
      <nav className={`nav ${open ? "show" : ""}`}>
        <NavLink to="/" className={navClass} onClick={() => setOpen(false)}>
          Home
        </NavLink>
        <NavLink to="/jobs" className={navClass} onClick={() => setOpen(false)}>
          Software Jobs
        </NavLink>
        <NavLink
          to="/government-jobs"
          className={navClass}
          onClick={() => setOpen(false)}
        >
          Government Jobs
        </NavLink>
        <NavLink
          to="/dresses"
          className={navClass}
          onClick={() => setOpen(false)}
        >
          Dresses
        </NavLink>
        <NavLink
          to="/jewellery"
          className={navClass}
          onClick={() => setOpen(false)}
        >
          Jewellery
        </NavLink>
        <NavLink
          to="/books"
          className={navClass}
          onClick={() => setOpen(false)}
        >
          Books
        </NavLink>
      </nav>
    </header>
  );
}