import { useState } from "react";
import "./Feedback.css";

export default function Feedback() {
  const [text, setText] = useState("");

  const submitFeedback = () => {
    const trimmed = (text || "").trim();
    if (!trimmed) {
      alert("Please enter feedback before submitting.");
      return;
    }

    // open WhatsApp chat to the configured number with prefilled message
    const phone = "918247202689"; // international format without +
    const message = encodeURIComponent(`Feedback from app:\n${trimmed}`);
    const url = `https://wa.me/${phone}?text=${message}`;

    // open in new tab/window
    window.open(url, "_blank");

    // clear textarea
    setText("");
  };

  return (
    <div className="feedback">
      <h3>Suggestions / Feedback</h3>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter your feedback..."
      />
      <button onClick={submitFeedback}>Submit</button>
    </div>
  );
}