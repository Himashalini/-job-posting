import "./SearchBar.css";

export default function SearchBar({ value, onChange }) {
  return (
    <input
      className="search-input"
      type="text"
      placeholder="Search by ID or name..."
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  );
}