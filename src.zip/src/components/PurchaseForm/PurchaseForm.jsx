import { useState } from "react";
import "./PurchaseForm.css";

export default function PurchaseForm({ productName, productId, onClose }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [quantity, setQuantity] = useState(1);

  const isValid =
    name.trim() &&
    phone.trim() &&
    address.trim() &&
    quantity > 0;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!isValid) return;

    const whatsappNumber =
      process.env.REACT_APP_WHATSAPP_NUMBER || "918247202689";

    const message = `🛒 *Order Request*

📦 Product: ${productName}
🆔 ID: ${productId}
🔢 Quantity: ${quantity}

👤 Name: ${name}
📞 Phone: ${phone}
🏠 Address: ${address}
`;

    window.open(
      `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`,
      "_blank"
    );

    onClose();
  };

  return (
    <div className="pf-card-overlay">
      <div className="pf-card-form">
        <h4>Buy {productName}</h4>

        <form onSubmit={handleSubmit}>
          {/* ✅ Product ID */}
          <input
            value={productId}
            readOnly
            placeholder="Product ID"
          />

          {/* ✅ NAME */}
          <input
            type="text"
            placeholder="Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />

          {/* ✅ PHONE */}
          <input
            type="tel"
            placeholder="Phone Number (10 digits)"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            pattern="[0-9]{10}"
            title="Please enter a valid 10-digit phone number"
          />

          {/* ✅ QUANTITY */}
          <input
            type="number"
            min="1"
            placeholder="Quantity"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            required
          />
          <p className="pf-help-text">
            Number of items you want to order
          </p>

          {/* ✅ ADDRESS */}
          <textarea
            placeholder="Delivery Address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />

          <div className="pf-actions">
            <button type="button" onClick={onClose}>
              Cancel
            </button>

            <button type="submit" disabled={!isValid}>
              Send via WhatsApp
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}