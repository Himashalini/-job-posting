import { useState, useRef } from "react";
import "./ImageSlider.css";

/* Build a safe full image URL */
const getFullSrc = (src) => {
  if (!src) return "/logo192.png";
  if (src.startsWith("http")) return src;

  const BASE = process.env.REACT_APP_API_BASE_URL || "";
  const ASSET_BASE = BASE.replace(/\/api\/?$/i, "").replace(/\/$/, "");
  return `${ASSET_BASE}/${src.replace(/^\//, "")}`;
};

export default function ImageSlider({ images = [] }) {
  const safeImages = Array.isArray(images) ? images : [];
  const [index, setIndex] = useState(0);
  const busy = useRef(false);

  const hasMultiple = safeImages.length > 1;

  const change = (dir) => {
    if (busy.current || !hasMultiple) return;
    busy.current = true;

    setIndex((i) =>
      dir === "prev"
        ? i === 0
          ? safeImages.length - 1
          : i - 1
        : i === safeImages.length - 1
        ? 0
        : i + 1
    );

    requestAnimationFrame(() => {
      busy.current = false;
    });
  };

  const src = getFullSrc(safeImages[index]);

  return (
    <div className="image-slider">
      <div className="image-slider-wrapper">

        {/* LEFT ARROW */}
        {hasMultiple && (
          <button
            type="button"
            className="image-slider-btn left"
            onMouseDown={(e) => {
              e.preventDefault();
              change("prev");
            }}
            onClick={() => change("prev")}
            aria-label="Previous image"
          >
            ‹
          </button>
        )}

        <img
          className="image-slider-img"
          src={src}
          alt=""
          loading="lazy"
          decoding="async"
          fetchpriority="high"
          onError={(e) => {
            e.currentTarget.src = "/logo192.png";
          }}
        />

        {/* RIGHT ARROW */}
        {hasMultiple && (
          <button
            type="button"
            className="image-slider-btn right"
            onMouseDown={(e) => {
              e.preventDefault();
              change("next");
            }}
            onClick={() => change("next")}
            aria-label="Next image"
          >
            ›
          </button>
        )}

      </div>
    </div>
  );
}
