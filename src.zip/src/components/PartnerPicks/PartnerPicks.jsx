import React, { useState } from "react";
import PartnerToggle from "./PartnerToggle";
import PartnerCard from "./PartnerCard";
import "./partner-picks.css";

export default function PartnerPicks({ directItems = [], partners = [], renderDirectGrid }) {
  const [view, setView] = useState("direct"); // 'direct' | 'partner'

  return (
    <section className="partner-picks-section">
      <PartnerToggle view={view} setView={setView} />

      <div className="partner-picks-content" aria-live="polite">
        {view === "direct" ? (
          renderDirectGrid ? (
            renderDirectGrid(directItems)
          ) : (
            <div className="grid direct-grid">
              {directItems.map((d) => (
                <div key={d.id} className="card">{/* reuse your card markup here */}</div>
              ))}
            </div>
          )
        ) : (
          <div>
            <div className="partner-disclosure-banner" role="status">
              <strong>Partner Picks</strong> — these items are affiliate links. We may earn a commission if you purchase through them at no extra cost to you.
            </div>

            <div className="grid partner-grid">
              {partners.length === 0 ? (
                <p className="muted">No Partner Picks available right now.</p>
              ) : (
                partners.map((p) => <PartnerCard key={p.id} item={p} />)
              )}
            </div>
          </div>
        )}
      </div>

      <p className="partner-disclosure muted-small">
        We may earn a commission from partner links; this does not affect the price you pay.
      </p>
    </section>
  );
}
