import React from "react";

export default function PartnerToggle({ view, setView }) {
  return (
    <div className="partner-toggle" role="tablist" aria-label="Collection view toggle">
      <button
        type="button"
        role="tab"
        aria-selected={view === "direct"}
        className={`partner-toggle-btn ${view === "direct" ? "active" : ""}`}
        onClick={() => setView("direct")}
      >
        Direct Buy Collection
      </button>

      <button
        type="button"
        role="tab"
        aria-selected={view === "partner"}
        className={`partner-toggle-btn ${view === "partner" ? "active" : ""}`}
        onClick={() => setView("partner")}
      >
        Partner Picks
      </button>
    </div>
  );
}
