import React from "react";

export default function PartnerCard({ item }) {
  return (
    <article className="partner-card" aria-labelledby={`partner-${item.id}-title`}>
      <div className="partner-card-media">
        <img
          src={item.image || "/logo192.png"}
          alt={item.name}
          loading="lazy"
          onError={(e) => (e.currentTarget.src = "/logo192.png")}
        />
      </div>

      <div className="partner-card-body">
        <h3 id={`partner-${item.id}-title`} className="partner-card-title">
          {item.name}
        </h3>

        <p className="partner-card-desc">{item.description}</p>

        <div className="partner-card-meta">
          <span className="partner-badge">Partner Pick</span>

          <a
            className="partner-visit-btn"
            href={item.url}
            target="_blank"
            rel="noopener noreferrer sponsored"
            aria-label={`View ${item.name} at store (opens in new tab)`}
          >
            View at Store
          </a>
        </div>
      </div>
    </article>
  );
}
