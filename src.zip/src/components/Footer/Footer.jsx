import "./Footer.css";
import { FaInstagram, FaYoutube, FaWhatsapp, FaEnvelope } from "react-icons/fa";
import { Link } from "react-router-dom";

export default function Footer() {
  const links = {
    jobInsta: "https://www.instagram.com/latest_job_hire",
    jobYoutube: "https://youtube.com/@majjigahimashalini2230",
    jobWhatsapp: "https://whatsapp.com/channel/0029VbAvE9ZAInPhNyWfxo2x",

    shopInsta: "https://www.instagram.com/styleunder599trend",
    shopYoutube: "https://youtube.com/@affination2230",
    shopWhatsapp: "https://whatsapp.com/channel/0029VbBQVJoEQIaox634nz2n",

    contactWhatsapp: "https://wa.me/918247202689",
    email: "mailto:himashalini676@gmail.com",
  };

  return (
    <footer className="footer">
      <div className="footer-grid">

        {/* ================= JOB UPDATES ================= */}
        <div className="footer-section">
          <h4>Job Updates</h4>
          <div className="footer-icons">
            <a href={links.jobInsta} target="_blank" rel="noreferrer">
              <FaInstagram />
            </a>
            <a href={links.jobYoutube} target="_blank" rel="noreferrer">
              <FaYoutube />
            </a>
            <a href={links.jobWhatsapp} target="_blank" rel="noreferrer">
              <FaWhatsapp />
            </a>
          </div>
        </div>

        {/* ================= PARTNER PICKS ================= */}
        <div className="footer-section">
          <h4>Partner Picks</h4>
          <div className="footer-icons">
            <a href={links.shopInsta} target="_blank" rel="noreferrer">
              <FaInstagram />
            </a>
            <a href={links.shopYoutube} target="_blank" rel="noreferrer">
              <FaYoutube />
            </a>
            <a href={links.shopWhatsapp} target="_blank" rel="noreferrer">
              <FaWhatsapp />
            </a>
          </div>
        </div>

        {/* ================= CONTACT ================= */}
        <div className="footer-section">
          <h4>Contact</h4>
          <div className="footer-icons">
            <a href={links.contactWhatsapp} target="_blank" rel="noreferrer">
              <FaWhatsapp />
            </a>
            <a href={links.email}>
              <FaEnvelope />
            </a>
          </div>
        </div>

        {/* ================= LEGAL ================= */}
        <div className="footer-section">
          <h4>Legal</h4>
          <div className="footer-icons">
            <Link to="/privacy-policy">PP</Link>
            <Link to="/terms">T&amp;C</Link>
          </div>
        </div>
      </div>
      <p className="small">
            Some links may be partner links. We may earn a commission
            at no extra cost to you.
          </p>

    </footer>
  );
}