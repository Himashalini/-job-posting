import ImageSlider from "../components/ImageSlider/ImageSlider";
import PurchaseForm from "../components/PurchaseForm/PurchaseForm";
import "./Card.css";

export default function DressCard({
  dress,
  activeDress,
  setActiveDress,
}) {
  const images = Array.isArray(dress.images) ? dress.images : [];
  const isActive = activeDress === dress.id;

  return (
    <div className="card" style={{ position: "relative" }}>
      {/* ✅ PURCHASE FORM */}
      {isActive && (
        <PurchaseForm
          productName={dress.name}
          productId={dress.id}
          onClose={() => setActiveDress(null)}
        />
      )}

      {images.length > 0 ? (
        <ImageSlider images={images} />
      ) : (
        <p>No images available</p>
      )}

      <h3>{dress.name}</h3>
      <p className="id">Dress ID: {dress.id}</p>
      <p className="price">₹ {dress.price}</p>
      <p className="desc">{dress.description}</p>

      <button onClick={() => setActiveDress(dress.id)}>
        Buy Now
      </button>
    </div>
  );
}