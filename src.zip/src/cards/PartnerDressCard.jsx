// src/cards/PartnerDressCard.jsx
import "./Card.css";

export default function PartnerDressCard({ dress }) {
  return (
    <div className="card">
      {dress.image_url ? (
        <img
          src={dress.image_url}
          alt={dress.name}
          className="job-img"
        />
      ) : (
        <div className="image-fallback">No image</div>
      )}

      <h3>{dress.name}</h3>
      <p className="desc">{dress.description}</p>

      <a
        href={dress.affiliateLink}
        target="_blank"
        rel="noreferrer"
        className="partner-btn"
      >
        View at Store
      </a>

      <p className="small center">Partner Pick</p>
    </div>
  );
}