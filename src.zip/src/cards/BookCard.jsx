import ImageSlider from "../components/ImageSlider/ImageSlider";
import PurchaseForm from "../components/PurchaseForm/PurchaseForm";
import "./Card.css";

export default function BookCard({
  book,
  activeBook,
  setActiveBook,
}) {
  const images = Array.isArray(book.images) ? book.images : [];
  const isActive = activeBook === book.id;

  return (
    <div className="card" style={{ position: "relative" }}>
      {/* ✅ PURCHASE FORM OVERLAY */}
      {isActive && (
        <PurchaseForm
          productName={book.title}
          productId={book.id}
          onClose={() => setActiveBook(null)}
        />
      )}

      {images.length > 0 ? (
        <ImageSlider images={images} />
      ) : (
        <p>No images available</p>
      )}

      <h3>{book.title}</h3>
      <p className="id">Book ID: {book.id}</p>
      <p className="price">₹ {book.price}</p>
      <p className="desc">{book.description}</p>

      <button onClick={() => setActiveBook(book.id)}>
        Buy Now
      </button>
    </div>
  );
}