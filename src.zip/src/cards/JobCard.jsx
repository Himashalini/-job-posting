import "./Card.css";

export default function JobCard({ job }) {
  return (
    <div className="card">
    {job.image_url ? (
        <img
          src={job.image_url}
          alt={job.title}
          className="job-img"
        />
      ) : (
        <div className="image-fallback">No image</div>
      )}
      <h3>{job.title}</h3>
      <p className="id">Job ID: {job.id}</p>
      <p className="company">{job.company}</p>
      <p className="desc">{job.description}</p>

      <button onClick={() => window.open(job.applyLink, "_blank")}>
        Apply Now
      </button>
    </div>
  );
}