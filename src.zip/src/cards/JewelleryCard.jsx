import ImageSlider from "../components/ImageSlider/ImageSlider";
import PurchaseForm from "../components/PurchaseForm/PurchaseForm";
import "./Card.css";

export default function JewelleryCard({
  jewellery,
  activeJewellery,
  setActiveJewellery,
}) {
  const images = Array.isArray(jewellery.images) ? jewellery.images : [];
  const isActive = activeJewellery === jewellery.id;

  return (
    <div className="card" style={{ position: "relative" }}>
      {/* ✅ PURCHASE FORM OVERLAY */}
      {isActive && (
        <PurchaseForm
          productName={jewellery.name}
          productId={jewellery.id}
          onClose={() => setActiveJewellery(null)}
        />
      )}

      {images.length > 0 ? (
        <ImageSlider images={images} />
      ) : (
        <p>No images available</p>
      )}

      <h3>{jewellery.name}</h3>
      <p className="id">Jewellery ID: {jewellery.id}</p>
      <p className="price">₹ {jewellery.price}</p>
      <p className="desc">{jewellery.description}</p>

      <button onClick={() => setActiveJewellery(jewellery.id)}>
        Buy Now
      </button>
    </div>
  );
}