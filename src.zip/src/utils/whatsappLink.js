export function openWhatsApp({ id, product }) {
  const message = `ID: ${id}\nProduct: ${product}\nPlease confirm availability.`;

  const number = process.env.REACT_APP_WHATSAPP_NUMBER || "918247202689"; // fallback support number

  // If number looks invalid, open the general contact link as a safe fallback
  const cleaned = String(number).replace(/[^0-9]/g, "");
  const url = `https://wa.me/${cleaned}?text=${encodeURIComponent(message)}`;

  window.open(url, "_blank");
}