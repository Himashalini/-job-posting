export function searchFilter(list, searchText) {
  // ensure we always work with an array
  const items = Array.isArray(list) ? list : [];

  if (!searchText) return items;

  const q = searchText.toString().toLowerCase();

  return items.filter(item =>
    item?.id?.toString().includes(q) ||
    (item?.title || "").toLowerCase().includes(q) ||
    (item?.name || "").toLowerCase().includes(q)
  );
}