import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Global handler for unhandled promise rejections to avoid uncaught console errors
window.addEventListener("unhandledrejection", (event) => {
  // Show a friendly toast for network / fetch failures
  const reason = event.reason;
  console.warn("Unhandled promise rejection:", reason);

  // If it's a network failure (TypeError: Failed to fetch), show a clearer message
  if (reason instanceof TypeError && /failed to fetch/i.test(String(reason.message))) {
    toast.error("Network error: could not reach the API. Is the backend running?");
  } else {
    toast.error("An unexpected error occurred. Check console for details.");
  }

  // Prevent the default logging to reduce noisy console stack traces during development
  // (still visible in console via our own console.warn above)
  event.preventDefault();
});

// Global error handler (optional)
window.addEventListener("error", (event) => {
  console.error("Global error:", event.error || event.message);
});

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
    <ToastContainer position="top-right" autoClose={3000} />
  </React.StrictMode>
);