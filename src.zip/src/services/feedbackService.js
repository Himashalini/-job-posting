const BASE_URL = process.env.REACT_APP_API_BASE_URL;

/**
 * Send feedback
 * POST /api/feedback
 */
export async function sendFeedback(data) {
  const res = await fetch(`${BASE_URL}/feedback`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });

  if (!res.ok) {
    throw new Error("Failed to send feedback");
  }
}
