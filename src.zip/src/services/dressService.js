const BASE_URL = process.env.REACT_APP_API_BASE_URL || "";

/**
 * Fetch all dresses
 * GET /api/dresses
 */
export async function getDresses() {
  const res = await fetch(`${BASE_URL}/dresses`);

  if (!res.ok) {
    throw new Error("Failed to fetch dresses");
  }

  const data = await res.json();

  // Normalize common shapes: array | { data: [...] } | { dresses: [...] } | { results: [...] }
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.data)) return data.data;
  if (data && Array.isArray(data.dresses)) return data.dresses;
  if (data && Array.isArray(data.results)) return data.results;

  // Fallback: if object with values, attempt to coerce to array
  if (data && typeof data === "object") return Object.values(data);

  return [];
}