const BASE_URL = process.env.REACT_APP_API_BASE_URL || "";

/**
 * Fetch all jewellery items
 * GET /api/jewellery
 */
export async function getJewellery() {
  const res = await fetch(`${BASE_URL}/jewellery`);

  if (!res.ok) {
    throw new Error("Failed to fetch jewellery");
  }

  const data = await res.json();

  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.data)) return data.data;
  if (data && Array.isArray(data.jewellery)) return data.jewellery;
  if (data && Array.isArray(data.results)) return data.results;
  if (data && typeof data === "object") return Object.values(data);

  return [];
}