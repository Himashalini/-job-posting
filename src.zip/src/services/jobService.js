const BASE_URL = process.env.REACT_APP_API_BASE_URL;

/**
 * Fetch all jobs
 * GET /api/jobs
 */
export async function getJobs() {
  const res = await fetch(`${BASE_URL}/jobs`);

  if (!res.ok) {
    throw new Error("Failed to fetch jobs");
  }
  const data = await res.json();

  // Normalize common API shapes: array, { data: [...] }, { jobs: [...] }
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.jobs)) return data.jobs;

  // If the backend returned an object with items keyed differently,
  // return an empty array instead of passing a non-array to the UI.
  return [];
}