import express from "express";
import cors from "cors";
import path from "path";
import compression from "compression";

import jobRoutes from "./routes/job.routes.js";
import dressRoutes from "./routes/dress.routes.js";
import jewelleryRoutes from "./routes/jewellery.routes.js";
import feedbackRoutes from "./routes/feedback.routes.js";
import authRoutes from "./routes/auth.routes.js";
import bookRoutes from "./routes/book.routes.js";

import govtJobRoutes from "./routes/govtJob.routes.js";

const app = express();

/* Global Middlewares */
app.use(cors());
app.use(express.json());

// Gzip compression for responses (improves transfer time for assets)
app.use(compression());

/* Base API Routes */
app.use("/api/jobs", jobRoutes);
app.use("/api/dresses", dressRoutes);
app.use("/api/jewellery", jewelleryRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/books", bookRoutes);

app.use("/api/govt-jobs", govtJobRoutes);


/* Health Check */
app.get("/", (req, res) => {
  res.json({ status: "✅ Backend is running" });
});

// Serve uploaded/static assets (if you store images locally under <project-root>/uploads)
// This lets the frontend request '/uploads/...' URLs and have the backend serve them.
// Serve uploads with caching for 7 days to reduce repeated downloads in production
app.use(
  "/uploads",
  express.static(path.join(process.cwd(), "uploads"), { maxAge: "7d" })
);

export default app;