import express from "express";
import {
  getDresses,
  createDress,
  updateDress,
  deleteDress,
} from "../controllers/dress.controller.js";

import { authMiddleware } from "../middleware/auth.middleware.js";
import { adminOnly } from "../middleware/role.middleware.js";
import { body, validationResult } from "express-validator";

const router = express.Router();

/* Public */
router.get("/", getDresses);

/* Admin - validate input to prevent bad/malicious data */
const dressValidators = [
  body("name").isString().trim().notEmpty().withMessage("Name is required"),
  body("price").isNumeric().withMessage("Price must be a number"),
  body("type").optional().isIn(["direct", "partner"]).withMessage("Invalid type"),
  body("affiliate_link").optional().isURL().withMessage("affiliate_link must be a valid URL"),
];

function runValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
}

router.post("/", authMiddleware, adminOnly, dressValidators, runValidation, createDress);
router.put("/:id", authMiddleware, adminOnly, dressValidators, runValidation, updateDress);
router.delete("/:id", authMiddleware, adminOnly, deleteDress);

export default router;
