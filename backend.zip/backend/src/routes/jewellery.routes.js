import express from "express";
import {
  getJewellery,
  createJewellery,
  updateJewellery,
  deleteJewellery,
} from "../controllers/jewellery.controller.js";

import { authMiddleware } from "../middleware/auth.middleware.js";
import { adminOnly } from "../middleware/role.middleware.js";
import { body, validationResult } from "express-validator";

const router = express.Router();

/* Public */
router.get("/", getJewellery);

/* Admin validation */
const jewelleryValidators = [
  body("name").isString().trim().notEmpty().withMessage("Name is required"),
  body("price").isNumeric().withMessage("Price must be a number"),
  body("type").optional().isIn(["direct", "partner"]).withMessage("Invalid type"),
  body("affiliate_link").optional().isURL().withMessage("affiliate_link must be a valid URL"),
];

function runValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
}

/* Admin */
router.post("/", authMiddleware, adminOnly, jewelleryValidators, runValidation, createJewellery);
router.put("/:id", authMiddleware, adminOnly, jewelleryValidators, runValidation, updateJewellery);
router.delete("/:id", authMiddleware, adminOnly, deleteJewellery);

export default router;
