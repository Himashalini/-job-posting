import { db } from "../config/database.js";

export const DressModel = {
  // ✅ READ - Get all dresses with images
  getAll: async () => {
    const [rows] = await db.query(`
      SELECT d.id, d.name, d.price, d.description,
             d.type, d.affiliate_link,
             GROUP_CONCAT(di.image_url) AS images
      FROM dresses d
      LEFT JOIN dress_images di ON d.id = di.dress_id
      GROUP BY d.id
      ORDER BY d.id DESC
    `);

    return rows.map(row => ({
      ...row,
      images: row.images ? row.images.split(",") : [],
      type: row.type || "direct",
      affiliate_link: row.affiliate_link || null,
    }));
  },

  // ✅ CREATE - Add a new dress with images
  create: async (dress) => {
    const { id, name, price, description, images, type = "direct", affiliate_link = null } = dress;
    await db.query(
      `INSERT INTO dresses (id, name, price, description, type, affiliate_link)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, name, price, description, type, affiliate_link]
    );

    if (Array.isArray(images)) {
      for (const img of images) {
        await db.query(
          `INSERT INTO dress_images (dress_id, image_url)
           VALUES (?, ?)`,
          [id, img]
        );
      }
    }
  },

  // ✅ UPDATE - Update dress details (not images here)
  update: async (id, dress) => {
    const { name, price, description, type = "direct", affiliate_link = null } = dress;
    await db.query(
      `UPDATE dresses
       SET name=?, price=?, description=?, type=?, affiliate_link=?
       WHERE id=?`,
      [name, price, description, type, affiliate_link, id]
    );
  },

  // ✅ DELETE - Remove dress and its images
  delete: async (id) => {
    await db.query(`DELETE FROM dress_images WHERE dress_id=?`, [id]);
    await db.query(`DELETE FROM dresses WHERE id=?`, [id]);
  },
};
