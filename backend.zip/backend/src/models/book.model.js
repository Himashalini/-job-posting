import { db } from "../config/database.js";

export const BookModel = {
  // READ - Get all books with images
  getAll: async () => {
    const [rows] = await db.query(`
      SELECT b.id, b.title, b.description, b.price,
             b.type, b.affiliate_link,
             GROUP_CONCAT(bi.image_url) AS images
      FROM books b
      LEFT JOIN book_images bi ON b.id = bi.book_id
      GROUP BY b.id
      ORDER BY b.id DESC
    `);

    return rows.map(row => ({
      id: row.id,
      title: row.title,
      description: row.description,
      price: row.price,
      images: row.images ? row.images.split(',') : [],
      type: row.type || 'direct',
      affiliate_link: row.affiliate_link || null,
    }));
  },

  create: async (book) => {
    const { id, title, description, price, images, type = 'direct', affiliate_link = null } = book;
    await db.query(
      `INSERT INTO books (id, title, description, price, type, affiliate_link)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, title, description, price, type, affiliate_link]
    );

    if (Array.isArray(images)) {
      for (const img of images) {
        await db.query(
          `INSERT INTO book_images (book_id, image_url) VALUES (?, ?)`,
          [id, img]
        );
      }
    }
  },

  update: async (id, book) => {
    const { title, description, price, type = 'direct', affiliate_link = null } = book;
    await db.query(
      `UPDATE books SET title=?, description=?, price=?, type=?, affiliate_link=? WHERE id=?`,
      [title, description, price, type, affiliate_link, id]
    );
  },

  delete: async (id) => {
    await db.query(`DELETE FROM book_images WHERE book_id=?`, [id]);
    await db.query(`DELETE FROM books WHERE id=?`, [id]);
  },
};
