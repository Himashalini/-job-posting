import { db } from "../config/database.js";

export const JewelleryModel = {
  // ✅ READ - Get all jewellery items with images
  getAll: async () => {
    const [rows] = await db.query(`
      SELECT j.id, j.name, j.price, j.description,
             j.type, j.affiliate_link,
             GROUP_CONCAT(ji.image_url) AS images
      FROM jewellery j
      LEFT JOIN jewellery_images ji ON j.id = ji.jewellery_id
      GROUP BY j.id
      ORDER BY j.id DESC
    `);

    return rows.map(row => ({
      ...row,
      images: row.images ? row.images.split(",") : [],
      type: row.type || "direct",
      affiliate_link: row.affiliate_link || null,
    }));
  },

  // ✅ CREATE - Add a new jewellery item with images
  create: async (item) => {
    const { id, name, price, description, images, type = "direct", affiliate_link = null } = item;
    await db.query(
      `INSERT INTO jewellery (id, name, price, description, type, affiliate_link)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, name, price, description, type, affiliate_link]
    );

    if (Array.isArray(images)) {
      for (const img of images) {
        await db.query(
          `INSERT INTO jewellery_images (jewellery_id, image_url)
           VALUES (?, ?)`,
          [id, img]
        );
      }
    }
  },

  // ✅ UPDATE - Update jewellery details (not images here)
  update: async (id, item) => {
    const { name, price, description, type = "direct", affiliate_link = null } = item;
    await db.query(
      `UPDATE jewellery
       SET name=?, price=?, description=?, type=?, affiliate_link=?
       WHERE id=?`,
      [name, price, description, type, affiliate_link, id]
    );
  },

  // ✅ DELETE - Remove jewellery item and its images
  delete: async (id) => {
    await db.query(`DELETE FROM jewellery_images WHERE jewellery_id=?`, [id]);
    await db.query(`DELETE FROM jewellery WHERE id=?`, [id]);
  },
};
