import { JewelleryModel } from "../models/jewellery.model.js";

// ✅ READ - Get all jewellery
export const getJewellery = async (req, res) => {
  try {
    const items = await JewelleryModel.getAll();
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch jewellery" });
  }
};

// ✅ CREATE - Add a new jewellery item
export const createJewellery = async (req, res) => {
  try {
    await JewelleryModel.create(req.body);
    res.status(201).json({ message: "Jewellery created successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to create jewellery" });
  }
};

// ✅ UPDATE - Modify an existing jewellery item
export const updateJewellery = async (req, res) => {
  try {
    await JewelleryModel.update(req.params.id, req.body);
    res.json({ message: "Jewellery updated successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to update jewellery" });
  }
};

// ✅ DELETE - Remove a jewellery item and its images
export const deleteJewellery = async (req, res) => {
  try {
    await JewelleryModel.delete(req.params.id);
    res.json({ message: "Jewellery deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete jewellery" });
  }
};
