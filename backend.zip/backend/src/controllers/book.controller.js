import { BookModel } from "../models/book.model.js";

export const getBooks = async (req, res) => {
  try {
    const books = await BookModel.getAll();
    res.json(books);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch books" });
  }
};

export const createBook = async (req, res) => {
  try {
    await BookModel.create(req.body);
    res.status(201).json({ message: "Book created successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to create book" });
  }
};

export const updateBook = async (req, res) => {
  try {
    await BookModel.update(req.params.id, req.body);
    res.json({ message: "Book updated successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to update book" });
  }
};

export const deleteBook = async (req, res) => {
  try {
    await BookModel.delete(req.params.id);
    res.json({ message: "Book deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete book" });
  }
};
