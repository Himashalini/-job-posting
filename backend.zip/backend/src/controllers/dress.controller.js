import { DressModel } from "../models/dress.model.js";

// ✅ READ - Get all dresses
export const getDresses = async (req, res) => {
  try {
    const dresses = await DressModel.getAll();
    res.json(dresses);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch dresses" });
  }
};

// ✅ CREATE - Add a new dress
export const createDress = async (req, res) => {
  try {
    await DressModel.create(req.body);
    res.status(201).json({ message: "Dress created successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to create dress" });
  }
};

// ✅ UPDATE - Modify an existing dress
export const updateDress = async (req, res) => {
  try {
    await DressModel.update(req.params.id, req.body);
    res.json({ message: "Dress updated successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to update dress" });
  }
};

// ✅ DELETE - Remove a dress and its images
export const deleteDress = async (req, res) => {
  try {
    await DressModel.delete(req.params.id);
    res.json({ message: "Dress deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete dress" });
  }
};
