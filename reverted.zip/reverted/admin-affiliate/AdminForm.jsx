import { useState } from "react";

export default function AdminForm({ fields, onSubmit }) {
  const initialState = fields.reduce((acc, field) => {
    if (field === "type") acc[field] = "direct";
    else acc[field] = "";
    return acc;
  }, {});

  const [formData, setFormData] = useState(initialState);

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
    setFormData(initialState);
  };

  return (
    <form onSubmit={handleSubmit}>
      {fields.map((field) => {
        if (field === "type") {
          return (
            <select
              key={field}
              value={formData.type}
              onChange={(e) => handleChange("type", e.target.value)}
            >
              <option value="direct">Direct</option>
              <option value="partner">Partner</option>
            </select>
          );
        }

        if (field === "affiliate_link") {
          return (
            formData.type === "partner" && (
              <input
                key={field}
                type="text"
                placeholder="affiliate link"
                value={formData.affiliate_link}
                onChange={(e) => handleChange("affiliate_link", e.target.value)}
                className="affiliate-input"
              />
            )
          );
        }

        return (
          <input
            key={field}
            type="text"
            placeholder={field.replace(/_/g, " ")}
            value={formData[field]}
            onChange={(e) => handleChange(field, e.target.value)}
            className={field === "affiliate_link" ? "affiliate-input" : ""}
            required={field !== "images"}
          />
        );
      })}

      <button type="submit">Save</button>
    </form>
  );
}
