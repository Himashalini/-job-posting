import { useState } from "react";

export default function EditForm({ initialData, fields, onSave, onCancel }) {
  const [formData, setFormData] = useState({ ...initialData });

  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>Edit Details</h3>

      {fields.map((field) => (
        <input
          key={field}
          type="text"
          placeholder={field.replace(/_/g, " ")}
          value={formData[field] ?? ""}
          onChange={(e) => handleChange(field, e.target.value)}
          className={field === 'affiliate_link' ? 'affiliate-input' : ''}
          required
        />
      ))}

      <div style={{ display: "flex", gap: "10px" }}>
        <button type="submit">Update</button>
        <button type="button" onClick={onCancel}>
          Cancel
        </button>
      </div>
    </form>
  );
}
